<?php require_once("Header.php") ?>
    <main>
        <article>
            <h1>Games</h1>
            <p>Deze pagina gaat over mijn hobby gamen, en nieuws erover.
                De games die ik veel speel op het moment zijn Rocket League, War Thunder, Battlefront, Battlefield en Ark.
            </p>
            <img src="img/ark.jpg" alt="ark" id="ark">
        </article>
    </main>

<?php require_once("Footer.php") ?>