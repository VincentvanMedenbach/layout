<?php require_once("Header.php") ?><?php require_once("Ads.php") ?>
    <main>
        <section class="Nieuws">
            <article class="Zooi">
                <h3>RollerCoaster Tycoon</h3>
                <img class="nieuwsIMG" src="img/RC.jpg" alt="woah">
                <p class="nieuwsartikelTEXT">RollerCoaster tycoon is uitgebracht op steam!</p>
                <a class="NieuwsArtikelIMG" href="Nieuws.Woah.php"> lees meer</a>
            </article>

            <article class="Zooi">
                <h3>Snes Mini uitgebracht</h3>
                <img class="nieuwsIMG" src="img/Snes.jpg" alt="Snes">
                <p class="nieuwsartikelTEXT">De Snes Mini is uitgebracht voor €80!</p>
                <a class="NieuwsArtikelIMG" href="Nieuws.ark.php">lees meer</a>
            </article>

            <article class="Zooi">
                <h3 class="nieuwsartikelTEXT">War thunder nieuwe update</h3>
                <img src="img/Wt.jpg" class="nieuwsIMG" alt="War thunder">
                <p class ="nieuwsartikelTEXT">Een nieuwe war thunder update, met een nieuwe tier!</p>
                <a class="NieuwsArtikelIMG" href="Nieuws.WarThunder.php">Lees meer</a>
            </article>

            <article class="Zooi">
                <h3>
                    Battlefront 2 Beta
                </h3>

                <img src="img/bf.jpg" class="nieuwsIMG" alt="battlefront">
                <p class="nieuwsartikelTEXT">Binnenkort kom de battlefront 2 beta uit!</p>
                <a class="NieuwsArtikelIMG" href="Nieuws.Battlefront%202.php">
                    lees meer</a>
            </article>
        </section>

    </main>
<?php require_once("Footer.php") ?>