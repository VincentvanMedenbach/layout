<section id="ad">
    <a href="https://www.ebay.com/p/Shrek-2-Sony-PlayStation-2-2004/6480827?iid=332363055241" target="_blank"><img alt="Add" class = "add" src="img/Shrek.jpg"></a>
    <a href="https://www.destructoid.com/review-mighty-morphin-power-rangers-mega-battle-415538.phtml" target="_blank"><img alt="txt" class = "add" src="img/Pwr.jpg"></a>

</section>