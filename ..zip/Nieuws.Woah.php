<?php require_once("Header.php") ?>
    <main>
        <article>
            <h1>ROLLERCOASTER TYCOON CLASSIC VANDAAG BESCHIKBAAR OP STEAM</h1>
            <p>RollerCoaster Tycoon Classic is vanaf nu beschikbaar op Steam. De game is een remaster met alle features
                van
                de eerste twee RollerCoaster Tycoon-games.<br><br>

                Atari werkt samen met Chris Sawyer om de game opnieuw naar de PC te brengen. Sawyer is de bedenker van
                de
                originele RollerCoaster Tycoon-games. Het is geen remake van de eerste games, maar een nieuwe
                interpretatie
                van de RollerCoaster-games, iets wat SEGA recent heeft gedaan met Sonic Mania.<br><br>
                <img class="BigImg" src="img/RC.jpg" alt="woah">

                <iframe src="http://store.steampowered.com/widget/683900/"></iframe>
                <br>


                De game bevat 95 verschillende scenarios en geeft je de Scenario Editor Toolkit, Wacky Worlds en Time
                Twister.<br><br>

                "Bijna twintig jaar geleden maakte ik een game waarvan ik nooit had durven dromen dat mensen het spel
                vandaag nog steeds spelen", aldus Sawyer.<br><br>

                RollerCoaster Tycoon Classic kost 19,99 euro.
            </p>
        </article>
    </main>
<?php require_once("Footer.php") ?>