<?php require_once("Header.php") ?>
    <main>
        <article>
            <h1>NINTENDO CLASSIC MINI: SUPER NINTENDO ENTERTAINMENT SYSTEM NU UIT</h1> <p>
                Vanaf vandaag is de Nintendo Classic Mini: Super Nintendo Entertainment System beschikbaar, de
                retroconsole van Nintendo die geleverd wordt met 21 SNES-klassiekers, direct op je tv is aan te sluiten
                en twee controllers kent.<br> <img class="BigImg" src="img/Snes.jpg" alt="IMG"><br>


                Gezien de grote vraag zal het wellicht lastig zijn om aan de console te komen wanneer je deze niet hebt
                gepre-orderd, maar Nintendo heeft wel laten weten dat de spelcomputer meer geproduceerd zal worden dan
                de NES-variant. Daarbij zal ook in 2018 productie plaatsvinden en als klap op de vuurpijl zou de NES
                Classic vanaf de zomer 2018 weer verkrijgbaar moeten zijn.
            </p>
        </article>
    </main>
<?php require_once("Footer.php") ?>