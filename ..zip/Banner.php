<section id="BannerAD">
    <a href="http://clicxa.com/advertise/banner-ads.html" target="_blank"><img id="BannerImg" src="img/download.jpg" alt="banner"></a>
</section>