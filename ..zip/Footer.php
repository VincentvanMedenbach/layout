<?php require_once("Banner.php") ?>
<footer>
    COPYRIGHT VINCEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEENT
</footer>
</body>

</html>