<?php require_once("Header.php") ?>
    <main>
        <article>
            <h1>War thunder nieuwe update</h1>
            <p><img src="img/Wt.jpg" class="BigImg" alt="War thunder">
                De update 1.71 introduceert Rank VI, een rang dat zal bestaan uit louter moderne voertuigen. De nieuwe
                tanks nemen twee nieuwe pantsers met zich mee; composiet en ‘explosive reactive’ pantser. Het eerste
                soort pantser zorgt ervoor dat de kinetische kracht van de tank kogels wordt verdeeld door het materiaal
                dat tussen twee lagen pantsers ligt. Het tweede soort pantser is als een soort schild bovenop het
                pantser, wat de kracht van een explosieve inslag opneemt. Het nadeel hiervan is dat dit soort pantser
                maar eenmalig te gebruiken is. Schiet de vijand nogmaals op hetzelfde stuk, dan zal de kogel hier dwars
                doorheen gaan.
            </p>
        </article>
    </main>
<?php require_once("Footer.php") ?>