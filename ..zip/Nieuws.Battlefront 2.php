<?php require_once("Header.php") ?>
<main>
    <h1>
        Starwars battlefront 2 beta
    </h1>
    <p>
        Uitgever Electronic Arts heeft de open bètatijden voor Star Wars Battlefront 2 bekendgemaakt. De open bèta
        begint op 6 oktober om 10:00 uur en eindigt op 9 oktober om 18:00 uur.<br><br>

        Wie de game van tevoren bestelt, krijgt op 4 oktober om 10:00 uur al toegang tot de servers. De open bèta is
        beschikbaar op de pc, PlayStation 4 en Xbox One.<br><br>

        Daarnaast geeft Electronic Arts aan dat de Star Wars Battlefront 2 open bèta de grootste is die het bedrijf ooit
        heeft georganiseerd. Er wordt gewaarschuwd dat het downloaden en installeren de nodige tijd in beslag neemt.<br><br>


        De open bèta bevat de Galactic Assault-modus op Naboo en de Starfighter Assault-modus op Fondor. Daarnaast is de
        Strike-modus te spelen in Maz Kanata's kasteel op Takodona en is er scenario uit de Arcade-modus beschikbaar die
        zich afspeelt op Theed.<br>
        <img src="img/bf.jpg" class="BigImg" alt="battlefront">
    </p>
</main>
<?php require_once("Footer.php") ?>