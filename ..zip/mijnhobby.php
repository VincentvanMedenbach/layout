<?php require_once("Header.php") ?>
<?php require_once("Ads.php") ?>
    <main class="container">
        <article>
            <h1>Gamen, mijn hobby</h1>
            <p>
                Een game die ik veel speel op het moment is Rocket League, deze speel ik vaak met vrienden.


            </p><img src="img/rl.jpg" alt="Rocket League">
        </article>
    </main>
<?php require_once("Footer.php") ?>